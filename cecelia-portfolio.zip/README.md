# Cecelia's Resume Website

这是按提供的完整源码打包的静态作品集网站，保留原有设计、文字和交互。

## 文件

| 文件 | 用途 |
| --- | --- |
| index.html | 完整网页，内含 CSS、JavaScript 和 SVG 插画 |
| README.md | 本说明 |
| .nojekyll | 空文件，用于跳过 GitHub Pages 的 Jekyll 处理 |

ZIP 解压后，这三个文件位于同一层。无需安装 npm 包，也无需编译或后端服务。

## 本地打开

解压 ZIP，用启用了 JavaScript 的现代浏览器打开 index.html。
当前插画和交互均包含在该文件中，无需下载外部素材。
手机或平板的文件预览可能不执行 JavaScript；发布后请在浏览器中打开网站网址体验完整交互。

## 发布到 GitHub Pages

1. 在 GitHub 新建仓库，例如 cecelia-portfolio。使用 GitHub Free 时，选择 Public。
2. 解压 ZIP，将 index.html、README.md 和 .nojekyll 上传到仓库的根目录，并提交到 main 分支。上传的是解压后的文件，不是 ZIP 本身。
3. 打开仓库的 Settings → Pages。
4. 在 Build and deployment 中，将 Source 设为 Deploy from a branch。
5. 分支选 main，文件夹选 / (root)，点击 Save。
6. 发布完成后，在同一页面点击 Visit site。

普通项目仓库的网址形式为：

https://YOUR-USERNAME.github.io/cecelia-portfolio/

请把 YOUR-USERNAME 替换成实际 GitHub 用户名；如仓库名称不同，网址中的仓库名也会不同。

.nojekyll 是以点开头的隐藏文件。若文件管理器没有显示它，请启用隐藏文件显示；也可以在仓库根目录补建同名空文件。index.html 必须直接位于所选发布目录，避免多套一层文件夹。

官方说明（2026-09-30 核对）：

- [创建 GitHub Pages 网站](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)
- [配置发布来源](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

## 添加自己的素材

在 index.html 中搜索 const CONTENT，编辑对应字段：

- originalGameUrl：原 A3 / p5.js 游戏的完整 http 或 https 网址。留空则隐藏入口。
- email：联系方式。填写有效邮箱后，About 区域会显示联系按钮。
- hiking、cocktails、archive：照片列表。

添加照片时，在 index.html 同级建立 assets 文件夹，上传照片，再将对应数组改为：

```js
hiking: [
  {
    src: "./assets/hiking-01.jpg",
    caption: "我的徒步记录"
  }
]
```

使用相对路径，并保持路径与文件名的大小写一致。照片文件需与网站一起上传。

## 当前内容与行为

- 保留全部 / 交互 / 视觉筛选、作品详情、个人收藏入口、工作室视差和键盘操作。
- The Next Chapter 包含婴儿房与童年房，可照料物品、切换夜灯、决定携带或留下泰迪，并重新探索。
- 游戏状态只保留在当前页面会话中；刷新或重新打开网页会重置。
- 个人照片、课程成果及原 A3 游戏网址仍为源码中的预留内容。
- 原文中的 UQT 等文字也按提供的源码保留，未进行文案或设计修改。
